package Comment;

import jakarta.validation.constraints.NotBlank;

import java.time.LocalDateTime;

public record CommentDto(Long id,
                         @NotBlank(message = "The message cannot be empty") String message,
                         String authorName,
                         Long topicId,
                         LocalDateTime createdAt) {
}
