package Comment;



import Infra.ResourceNotFoundException;
import Topic.TopicRepository;
import User.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    private final CommentRepository commentRepository;
    private final UserRepository userRepository;
    private final TopicRepository topicRepository;

    public CommentService(CommentRepository commentRepository, UserRepository userRepository,
                          TopicRepository topicRepository) {
        this.commentRepository = commentRepository;
        this.userRepository = userRepository;
        this.topicRepository = topicRepository;
    }
    @Transactional
    public void creationNewComment(Long topicId, String message) {
        String username = ((UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
                .getUsername();
        User author = userRepository.findByUsername(username);
        if (author == null) {
            throw new ResourceNotFoundException("Usuario no encontrado: " + username);
        }
        Topic topic = topicRepository.findById(topicId)
                .orElseThrow(() -> new ResourceNotFoundException("Topic not found with id: " + topicId));

        boolean commentExists = commentRepository.existsByTopicAndMessage(topic, message);
        if (commentExists) {
            throw new IllegalArgumentException("Ya existe un comentario idéntico en este tópico");
        }
        Comment comment = Comment.builder()
                .author(author)
                .message(message)
                .topic(topic)
                .build();

        commentRepository.save(comment);
    }

}

