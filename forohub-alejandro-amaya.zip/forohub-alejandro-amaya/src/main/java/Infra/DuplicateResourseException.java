package Infra;

public class DuplicateResourseException extends RuntimeException {
    public DuplicateResourseException(String message) {
        super(message);
    }
}
