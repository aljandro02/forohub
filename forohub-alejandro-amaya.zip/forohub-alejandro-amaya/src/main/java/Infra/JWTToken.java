package Infra;

public record JWTToken(String jwtoken) {
}
