package Course;

public enum CourseCategoryEnum {
    BACKEND, FRONTEND, DATA_SCIENCE, MACHINE_LEARNING, DEVELOPMENT_OPS
}
