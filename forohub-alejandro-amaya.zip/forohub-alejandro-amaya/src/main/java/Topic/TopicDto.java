package Topic;

import Comment.CommentDto;

import java.time.LocalDate;
import java.util.List;

public record TopicDto(Long id,
                       String title,
                       String message,
                       LocalDate createdAt,
                       TopicStatusEnum status,
                       String authorName,
                       LocalDate updatedAt,
                       List<CommentDto> comments) {
}
