package Topic;

import java.time.LocalDateTime;

public record TopicUpdateDto(String title,
                             String message,
                             TopicStatusEnum status,
                             LocalDateTime updateAt) {
}
