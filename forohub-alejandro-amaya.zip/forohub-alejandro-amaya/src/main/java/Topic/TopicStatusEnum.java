package Topic;

public enum TopicStatusEnum {
    OPEN, CLOSED,SOLVED
}
