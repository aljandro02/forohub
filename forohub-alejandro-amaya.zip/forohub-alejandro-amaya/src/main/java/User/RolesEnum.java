package User;

public enum RolesEnum {
    USER,ADMIN
}
