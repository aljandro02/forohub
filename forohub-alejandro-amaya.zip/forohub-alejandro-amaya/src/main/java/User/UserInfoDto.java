package User;

import java.util.stream.Collectors;

public record UserInfoDto(
        String name,
        String username,
        String email,
        String roles
) {
    public UserInfoDto(User User) {
        this(User.getName(), User.getUsername(), User.getEmail(),
                User.getRoles().isEmpty() ? RolesEnum.USER.name()
                        : User.getRoles().stream()
                        .map(role -> role.getName().name())
                        .collect(Collectors.joining(", ")));
    }

}
